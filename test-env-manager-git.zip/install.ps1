# install.ps1 - Git-based setup for Test Environment Manager

$repoUrl = "https://github.com/your-username/test-env-manager.git"
$projectDir = "$PWD\test-env-manager"

Write-Host "📦 Cloning repository..."
git clone $repoUrl

# ---- BACKEND SETUP ----
Write-Host "`n🐍 Setting up Python backend..."
$backendDir = "$projectDir\backend"
cd $backendDir

python -m venv venv
.\venv\Scripts\Activate.ps1
pip install --upgrade pip
pip install -r requirements.txt

Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd `"$backendDir`"; .\venv\Scripts\Activate.ps1; uvicorn main:app --reload --port 8000"

# ---- FRONTEND SETUP ----
Write-Host "`n⚛️ Setting up React frontend..."
$frontendDir = "$projectDir\frontend"
cd $frontendDir
npm install

Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd `"$frontendDir`"; npm start"

Write-Host "`n✅ Test Environment Manager is launching:"
Write-Host "🔗 Frontend: http://localhost:3000"
Write-Host "🔗 Backend:  http://localhost:8000"